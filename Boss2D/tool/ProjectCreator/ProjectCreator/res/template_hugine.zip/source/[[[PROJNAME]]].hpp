﻿#pragma once
#include <service/hu_zay.hpp>
#include <service/hu_zaywidget.hpp>

class [[[PROJNAME]]]Data : public ZayObject
{
public:
    [[[PROJNAME]]]Data();
    ~[[[PROJNAME]]]Data();

public:
    // 업데이트요청
    uint64 mUpdateMsec;
    // 제이에디터 위젯
    ZayWidget mWidget;
};
